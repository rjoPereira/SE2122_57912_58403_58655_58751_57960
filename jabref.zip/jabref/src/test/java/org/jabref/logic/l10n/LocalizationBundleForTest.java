package org.jabref.logic.l10n;

enum LocalizationBundleForTest {
    LANG, MENU
}
