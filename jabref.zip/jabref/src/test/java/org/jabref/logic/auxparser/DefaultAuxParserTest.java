package org.jabref.logic.auxparser;

/**
 * Please see {@link AuxParserTest} for the test cases
 */
class DefaultAuxParserTest {

}
